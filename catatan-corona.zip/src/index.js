import "regenerator-runtime";
import "bootstrap/dist/css/bootstrap.min.css";
import "./styles/main.css";
import "./scripts/component/navbar.js";
import "./scripts/component/corona.js";
import "./scripts/component/footer.js"
import main from "./scripts/main";
main();